#include <stdio.h>

// prototipo para la rutina en ensamblador
int det(int, int, int, int) __attribute__((cdec1));

int main(void)
{
	int a, b, c, d;

	printf("\nResta de productos cruzados:\n");
	printf("Ingrese cuatro enteros:\n");
	printf("#1: ");
	scanf("%d",&a);
	printf("\n#2: ");
	scanf("%d",&b);
	printf("\n#3: ");
	scanf("%d",&c);
	printf("\n#4: ");
	scanf("%d",&d);

	printf("\nResultado: %d\n", det(a, b, c, d));
	
	return 0;
}

/*
Compilacion:

nasm -f elf tp.asm

gcc -o programa tp_driver.c tp.o asm_io.o
*/